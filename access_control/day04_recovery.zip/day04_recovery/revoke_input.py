# 10/29(목)에 결석한 학생용입니다. 어제 점검 결과인 「회수 대상」 8건을 그대로 담았습니다.
# 10/29(목) 파일(review_list.py 등)이 없어도 오늘 수업을 따라올 수 있습니다. 이 파일만 access_control 폴더에 넣고, 고치지 않습니다.


def load_to_revoke():                                            # 어제 점검 결과(회수 대상)를 리턴하는 함수
    """어제(10/29(목)) 점검에서 나온 「회수 대상」 리스트(8건)를 리턴한다."""
    to_revoke = [                                                # 회수 대상 8건(역할로 받은 3건 + 예외로 받은 5건)
        {"user": "junho", "permission": "SALES:QUERY", "source": "역할 finance", "employed": True, "reasons": ["90일 넘게 안 씀(이력 없음 포함)"]},
        {"user": "dami", "permission": "SALES:QUERY", "source": "역할 sales", "employed": False, "reasons": ["퇴사한 계정"]},
        {"user": "dami", "permission": "SALES:CHANGE", "source": "역할 sales", "employed": False, "reasons": ["퇴사한 계정", "90일 넘게 안 씀(이력 없음 포함)"]},
        {"user": "seoyeon", "permission": "SETTLE:QUERY", "source": "예외 1번", "employed": True, "expires": "2026-10-22 18:00", "reasons": ["만료된 예외", "90일 넘게 안 씀(이력 없음 포함)"]},
        {"user": "junho", "permission": "SALES:CHANGE", "source": "예외 2번", "employed": True, "expires": "2026-10-20 18:00", "reasons": ["만료된 예외", "90일 넘게 안 씀(이력 없음 포함)"]},
        {"user": "dami", "permission": "SALES:QUERY", "source": "예외 3번", "employed": False, "expires": "2026-10-31 18:00", "reasons": ["퇴사한 계정"]},
        {"user": "batch-night", "permission": "SALES:QUERY", "source": "예외 4번", "employed": True, "expires": "2026-10-23 09:00", "reasons": ["만료된 예외", "90일 넘게 안 씀(이력 없음 포함)"]},
        {"user": "gaeun", "permission": "SETTLE:QUERY", "source": "예외 5번", "employed": True, "expires": "2026-10-22 12:00", "reasons": ["만료된 예외", "90일 넘게 안 씀(이력 없음 포함)"]},
    ]
    return to_revoke                                             # 회수 대상 리스트를 리턴한다
